
        <footer class="app-footer">
            <div class="wrapper">
                <table border="0" width="100%">
                	<tr>
                		<td>&copy; Néoveille 2015-<?php echo date("Y"); ?></td>
                		<td><img src="images/idex.png" width="150px"/></td>
                		<td><img src="images/uspc.png" width="150px"/></td>
                		<td><img src="images/up13.png" width="150px"/></td>
                		<td><img src="images/up7.png" width="130px"/></td>
                		<td><img src="images/inalco.png" width="150px"/></td>
                		<td><img src="images/saopaulo.png" width="150px"/></td>
                		<td>groupe EMPNEO</td>
                	</tr>
                	<tr>
                	   <td colspan="2">&nbsp;</td>
                       <td><a href="https://lipn.univ-paris13.fr/fr/rcln-3" target="new"><img src="images/lipn.png" width="40px"/></a></td>
                		<td><a href="http://www.clillac-arp.univ-paris-diderot.fr" target="new"><img src="images/clillacarp.png" width="40px"/></a></td>
                		<td><a href="http://www.er-tim.fr" target="new"><img src="images/ertim.png" width="30px"/></a></td>
                		<td><a href="http://ldi.cnrs.fr/index.php?lang=fr" target="new"><img src="images/ldi.png" width="40px"/></a></td>
                		<td colspan="2">&nbsp;</td>
                	</tr>
                </table>

            </div>
        </footer>
        <div>
            <!-- Javascript Libs -->
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/autofill/2.2.2/js/dataTables.autoFill.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/autofill/2.2.2/js/autoFill.bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/colreorder/1.4.1/js/dataTables.colReorder.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/fixedcolumns/3.2.4/js/dataTables.fixedColumns.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/fixedheader/3.1.3/js/dataTables.fixedHeader.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.1/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.1/js/responsive.bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/scroller/1.4.4/js/dataTables.scroller.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/select/1.2.5/js/dataTables.select.min.js"></script>

<script type="text/javascript" charset="utf-8" src="Editor/js/dataTables.editor.min.js"></script>
<script type="text/javascript" charset="utf-8" src="Editor/js/editor.bootstrap.min.js"></script>
            <script type="text/javascript" charset="utf-8" src="js/editor.title.js"></script>
	    	<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/dataTables.buttons.min.js"></script>
	    	<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.flash.min.js"></script>
            <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.print.min.js"></script>
            <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.html5.min.js"></script>
	    	<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.colVis.min.js"></script>


            <script type="text/javascript" src="js/menus.js"></script>
            <script type="text/javascript">
            var user = '<?php echo $_SESSION["user"]; ?>';
            var user_rights = '<?php echo $_SESSION["user_rights"]; ?>';
           var languageW = '<?php echo $_SESSION["language"]; ?>';
            </script>
