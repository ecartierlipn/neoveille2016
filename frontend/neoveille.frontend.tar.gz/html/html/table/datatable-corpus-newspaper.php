<script type="text/javascript" charset="utf-8" src="js/table.RSS_journaux.js"></script>

                <div class="side-body">
                    <div class="page-title">
                        <span class="title">Gestionnaire de corpus : liste des journaux</span>
                        <div class="description">
                        Cette interface vous permet de consulter et d'éditer la liste des journaux dans Neoveille. 
	Vous pouvez trier et filter les entrées.
						</div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="card">
                                <div class="card-body">
                                    <table class="datatable table table-striped" cellspacing="0" id="RSS_INFO">
				<thead>
					<tr>
						<th>Journal</th>
						<th>Description</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th>Journal</th>
						<th>Description</th>
					</tr>
				</tfoot>	
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>