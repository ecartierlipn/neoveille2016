
		<script type="text/javascript" charset="utf-8" src="js/table.neodb-params.js"></script>

                <div class="side-body">
                    <div class="page-title">
                        <span class="title">Gestionnaire des matrices néologiques</span>
                        <div class="description">
                        Cette interface vous permet de consulter et d'éditer la liste des matrices néologiques dans Neoveille. 
	Vous pouvez trier, filter, ajouter et modifier les entrées.
						</div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="card">
                                <div class="card-body">
          <table class="datatable table" cellspacing="0" id="RSS_INFO">
				<thead>
					<tr>
						<th>Catégorie de matrice</th>
						<th>Sous-catégorie</th>
						<th>Code</th>
						<th>Libellé</th>
						<th>Définition</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th>Catégorie de matrice</th>
						<th>Sous-catégorie</th>
						<th>Code</th>
						<th>Libellé</th>
						<th>Définition</th>
					</tr>
				</tfoot>			
          </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>