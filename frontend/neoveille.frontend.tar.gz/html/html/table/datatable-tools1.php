
		<script type="text/javascript" charset="utf-8" src="js/table.tools1.js"></script>

                <div class="side-body">
                    <div class="page-title">
                        <span class="title">Gestionnaire de bugs et demandes de fonctionnalités</span>
                        <div class="description">
                        Cette interface vous permet de consulter les bugs et demandes de fonctionnalités de la plateforme.
                        Avant de saisir un nouveau bug ou une nouvelle demande, merci de consulter les entrées déjà saisies, classées par module.
						</div>
                    </div>            
			<div id="info"><!-- see js file for activating filters -->
				<table><tr><td colspan="7"><h5>Filtres</h5></td></tr>
					<tr><td id="filter_module"></td><td id="filter_type"></td><td id="filter_message"></td><td id="filter_state"></td><td id="filter_author"></td>
					<tr><td colspan="7"></td></tr>
				</table>  
            </div>             
            <div class="row">
                        <div class="col-xs-12">
                            <div class="card">
                                <div class="card-body">
                                    <table class="datatable table" cellspacing="0" id="table-neo-tools">
				<thead>
					<tr>
						<th>Module</th>
						<th>Type</th>
						<th>Description</th>
						<th>Etat</th>
						<th>Auteur</th>
						<th>&nbsp;</th>
						<th>&nbsp;</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th>Module</th>
						<th>Type</th>
						<th>Description</th>
						<th>Etat</th>
						<th>Auteur</th>
						<th>&nbsp;</th>
						<th>&nbsp;</th>
					</tr>
				</tfoot>				
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>