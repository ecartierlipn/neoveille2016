<script type="text/javascript" charset="utf-8" src="js/table.RSS_FORMAT.js"></script>

                <div class="side-body">
                    <div class="page-title">
                        <span class="title">Gestionnaire de corpus : formats des données</span>
                        <div class="description">
                        Cette interface vous permet de consulter et d'éditer la liste des formats de fichiers utilisées dans Neoveille. 
	Vous pouvez trier, filter, ajouter et modifier les entrées.
						</div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="card">
                                <div class="card-body">
                                    <table class="datatable table table-striped" cellspacing="0" id="RSS_INFO">
				<thead>
					<tr>
						<th>Nom format</th>
						<th>Description format</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th>Nom format</th>
						<th>Description format</th>
					</tr>
				</tfoot>			
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>