
<script type="text/javascript" charset="utf-8" src="js/table.user-profile.js"></script>

	<div class="side-body">
    	<div class="page-title">
        	<span class="title">Gestionnaire de Profil / Préférences</span>
		</div>
        <div class="description">
            <div class="row">
            	<div class="col-xs-12">
                	<div class="card">
                    	<div class="card-body">
                            <table class="datatable table" cellspacing="0" id="usersT">
								<thead>
									<tr>
										<th>Utilisateur</th>
										<th>Email</th>
										<th>Prénom</th>
										<th>Nom</th>
										<th>Droits</th>
										<th>Langue de travail</th>
										<th></th>
										<th></th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th>Utilisateur</th>
										<th>Email</th>
										<th>Prénom</th>
										<th>Nom</th>
										<th>Droits</th>
										<th>Langue de travail</th>
										<th></th>
										<th></th>
									</tr>
								</tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>