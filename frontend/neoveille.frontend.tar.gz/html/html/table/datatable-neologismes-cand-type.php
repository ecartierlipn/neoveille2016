
		<script type="text/javascript" charset="utf-8" src="js/table.neologismes-types.js"></script>

                <div class="side-body">
                    <div class="page-title">
                        <span class="title">Gestionnaire des types de néologismes candidats</span>
                        <div class="description">
                        Cette interface vous permet de consulter et d'éditer la liste des types de candidats néologismes dans Neoveille. 
	Vous pouvez trier, filter, ajouter et modifier les entrées.
						</div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="card">
                                <div class="card-body">
          <table class="datatable table table-striped" cellspacing="0" id="RSS_INFO">
				<thead>
					<tr>
						<th>Libellé</th>
						<th>Description</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th>Libellé</th>
						<th>Description</th>
					</tr>
				</tfoot>			
          </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>