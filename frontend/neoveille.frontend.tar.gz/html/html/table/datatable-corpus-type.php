<script type="text/javascript" charset="utf-8" src="js/table.RSS_TYPE.js"></script>

                <div class="side-body">
                    <div class="page-title">
                        <span class="title">Gestionnaire de corpus : liste des domaines</span>
                        <div class="description">
                        Cette interface vous permet de consulter et d'éditer la liste des domaines dans Neoveille. 
	Vous pouvez trier et filter les entrées.
						</div>
                    </div>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="card">
                                <div class="card-body">
                                    <table class="datatable table table-striped" cellspacing="0" id="RSS_INFO">
				<thead>
					<tr>
						<th>Nom domaine</th>
						<th>Description domaine</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th>Nom domaine</th>
						<th>Description domaine</th>
					</tr>
				</tfoot>	
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>