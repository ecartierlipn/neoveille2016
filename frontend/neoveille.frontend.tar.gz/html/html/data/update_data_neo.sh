cd /var/www/html/html/data
python generate_neologisms_synthesis.py
