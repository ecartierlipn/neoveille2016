cd /var/www/html/html/data
python3 generate_corpus_synthesis.py
