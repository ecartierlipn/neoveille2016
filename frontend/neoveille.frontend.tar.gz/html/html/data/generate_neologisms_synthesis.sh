cd /var/www/html/html/data
python3 generate_neologisms_synthesis.py
