<?php
  header('Location: http://tal.lipn.univ-paris13.fr/neoveille/html/');
  exit();
?>
